let plants = []; // Array para armazenar as plantas

function setup() {
  createCanvas(800, 600); // Criar um canvas de 800x600
  background(200, 255, 200); // Cor do fundo verde claro
}

function draw() {
  // Desenhar as plantas
  for (let plant of plants) {
    plant.grow(); // Chamar a função de crescimento
    plant.display(); // Exibir a planta
  }
}

// Função para a interação do usuário
function mousePressed() {
  let newPlant = new Plant(mouseX, mouseY); // Criar uma nova planta na posição do clique
  plants.push(newPlant); // Adicionar a planta ao array
}

// Classe para representar as plantas
class Plant {
  constructor(x, y) {
    this.x = x; // Posição x
    this.y = y; // Posição y
    this.size = 5; // Tamanho inicial da planta
    this.growthRate = 0.1; // Taxa de crescimento
  }

  grow() {
    this.size += this.growthRate; // Aumentar o tamanho da planta
  }

  display() {
    fill(100, 200, 100); // Cor da planta
    ellipse(this.x, this.y, this.size, this.size); // Desenhar a planta como um círculo
  }
}